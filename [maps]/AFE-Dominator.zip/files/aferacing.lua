addEventHandler('onClientResourceStart', resourceRoot,
    function()
        outputChatBox ( "Made by AFE Racing team. Drive hard, get dirty!")

        local txd = engineLoadTXD('files/1.txd',true)
        engineImportTXD(txd, 2053)
 
        local dff = engineLoadDFF('files/1.dff', 0)
        engineReplaceModel(dff, 2053)
 
        local col = engineLoadCOL('files/1.col')
        engineReplaceCOL(col, 2053)
        engineSetModelLODDistance(2053, 500)
    end
)